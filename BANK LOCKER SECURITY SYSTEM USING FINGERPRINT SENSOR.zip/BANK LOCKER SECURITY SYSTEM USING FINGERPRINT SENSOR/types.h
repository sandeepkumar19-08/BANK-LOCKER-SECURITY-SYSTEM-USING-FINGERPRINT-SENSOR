typedef unsigned char u8;
typedef char s8;
typedef int s32;
typedef unsigned int u32;
typedef short s16;
typedef unsigned short u16;
typedef float f32;
typedef double d64;
