#include "types.h"
void ipop(u32 portno, u32 pinno, u32 func);
void ioset(u32 portno, u32 pinno, u32 func);
void ioclr(u32 portno, u32 pinno, u32 func);
void iopin(u32 portno, u32 pinno, u32 func);
