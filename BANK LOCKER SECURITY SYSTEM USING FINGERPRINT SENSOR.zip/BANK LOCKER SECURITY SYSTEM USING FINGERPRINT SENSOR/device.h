#ifndef _DEVICE_H_

#define _DEVICE_H_


void motor_open(void);
void motor_close(void);


#endif
