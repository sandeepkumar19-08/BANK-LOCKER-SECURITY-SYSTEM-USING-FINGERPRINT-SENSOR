#ifndef __TIMER_dEFINES_H__
#define __TIMER_dEFINES_H__
#define TIMER0_ENABLE 0X01
#define TIMER0_RST 0X02
#define TIMER0_RST_ON_MR0 0X02
#define TIMER0_STOP_ON_MR0 0X04
#endif
