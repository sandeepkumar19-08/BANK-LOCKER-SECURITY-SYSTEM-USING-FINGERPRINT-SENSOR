                 /* external_interrupt_test.c */
#include <lpc21xx.h>
#include "pin_function_defines.h"
#include "defines.h"
#include "ext_int.h"
#include "lcd.h"
#include"lcd_defines.h"
#include"kpm.h"
#include "spi_eeprom.h"
#include "delay.h"
#include "uart0.h"
#include "R305.h" 
#include "spi.h"
#include<string.h>

unsigned char a;


void Enable_EINT1(void)
{
	//CFGPIN(PINSEL0,3,FUNC4);
	PINSEL0|=0x000000C0;
	SSETBIT(VICIntEnable,15);
	VICVectCntl1=0x20|15;
	VICVectAddr1=(unsigned)eint1_isr;
	
	//Enable EINT0 
	//SCLRBIT(EXTINT,0) //default
	//EXTINT=1<<0;
	//EXTMODE=1<<0;
	//EINT0 as EDGE_TRIG
  SETBIT(EXTMODE,1);
	//EINT0 as REDGE
  CLRBIT(EXTPOLAR,1);	
}	

void eint1_isr(void) __irq
{
	a=1;
	SCLRBIT(EXTINT,1);//clear flag
	VICVectAddr=0;
}	

