#include<LPC21xx.h>
#include "types.h"
#include "defines.h"
#include "delay.h"
#define CA7SEG_2_MUX 8
#define SEG1 16
#define SEG2 17
const u8 segLUT[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
u32 i,dly;
int main()
{
	//IOPIN0=(IOPIN0&~(255<<CA7SEG_2_MUX))|(0XFF<<CA7SEG_2_MUX);
	WRITEBYTE(IODIR0,CA7SEG_2_MUX,0XFF);
	SETBIT(IODIR0,SEG1);
	SETBIT(IODIR0,SEG2);
	for(i=0;i<=99;i++)
	{
		for(dly=100;dly>0;dly--)
		{
			WRITEBYTE(IOPIN0,CA7SEG_2_MUX,segLUT[(i/10)]);
			SSETBIT(IOPIN0,SEG1);
			delay_ms(1);
			SCLRBIT(IOPIN0,SEG1);
			WRITEBYTE(IOPIN0,CA7SEG_2_MUX,segLUT[(i%10)]);
			SSETBIT(IOPIN0,SEG2);
			delay_ms(1);
			SCLRBIT(IOPIN0,SEG2);
		}
	}
	while(1);
}

