#include<LPC21XX.h>
#include"defines.h"
#include"types.h"
#include"delay.h"
#include"lcd.h"
#include"lcd_defines.h"
#include"kpm.h"
#include "ext_int.h"
#include "spi.h"
#include "spi_eeprom.h"
#include "device.h"
#include "R305.h" 
#include "uart0.h"
#include<string.h>
#include <stdlib.h>
#define SW_AL 2
unsigned char pass[5],curpass[5],newpass[5];
unsigned char *pas=pass,*curpas=curpass,*newpas=newpass;
unsigned char choose;
unsigned int pageid,p;
u8 userid[5],ruserid[5],pwd[5],rpwd[5];
u8*usrid=userid,*rusrid=ruserid,*pd=pwd,*rpd=rpwd;
void menu(void);
void edit_pass(void);
void edit_fp(void);
extern unsigned char a;
extern int flag;
int main()
{
	InitUART0();
	Init_SPI();
	InitLCD();
	Init_KPM();
	Enable_EINT1();
	PageWrite_25LC512(0x000f,"2");
	PageWrite_25LC512(0x0000,"1111");
	while(1)
	{
 LABEL1:CmdLCD(CLEAR_LCD);
		CmdLCD(GOTO_LINE1_POS0);
		StrLCD("Enter id:");
		while(ColScan()==1)
		{
			if(a==1)
			{
			
				menu();
				goto LABEL1;
			}
		}
		CmdLCD(GOTO_LINE2_POS0);
		usrid=Readid(userid);
		PageRead_25LC512(0x000F,1,ruserid);
		if(!(strcmp((const char*)usrid,(const char*)ruserid)))
		{
			CmdLCD(CLEAR_LCD);
			CmdLCD(GOTO_LINE1_POS0);
			StrLCD("Enter 4 digit pwd:");
			CmdLCD(GOTO_LINE2_POS0);
			pd=Readpass(pd);
			PageRead_25LC512(0x0000,4,rpwd);
			if(!(strcmp((const char*)pd,(const char*)rpwd)))
			{
				CmdLCD(0x01);
	   			CmdLCD(0x80);
          		if(search_fp())
				{
					CmdLCD(CLEAR_LCD);
					CmdLCD(GOTO_LINE1_POS0);
					StrLCD("BANK LOCK OPEN");
					do
					{
					 	if(flag==0)
							motor_open();
					}while(READBIT(IOPIN0,SW_AL)==1);
					motor_close();
				} 
				delay_ms(1000);
			}
			else
			{
				CmdLCD(CLEAR_LCD);
				CmdLCD(GOTO_LINE1_POS0);
				StrLCD("pwd incorrect");
				CmdLCD(GOTO_LINE2_POS0);
				StrLCD("Wait & Enter agn");
				delay_s(1);
			}
		}
		else
		{
			CmdLCD(CLEAR_LCD);
			CmdLCD(GOTO_LINE1_POS0);
			StrLCD("Usr id incorrect");
			CmdLCD(GOTO_LINE2_POS0);
			StrLCD("Wait & Enter agn");
			delay_s(1);
		}
	}
}


void menu()
{
	a=0;
	CmdLCD(CLEAR_LCD);
	CmdLCD(GOTO_LINE1_POS0);
	StrLCD("MENU: ");
	StrLCD("1)Edit pass");
	CmdLCD(GOTO_LINE2_POS0);
	StrLCD("2)Edit FP 3)EXIT");
	if(KeyScan()=='1')
	{
		edit_pass();
		return;
	}	
	if(KeyScan()=='2')
	{
		edit_fp();
	}
	return;
}
void edit_fp(void)
{
     
    CmdLCD(0x01);
    CmdLCD(0x80);
    StrLCD("FINGER PRINT ");

    delay_ms(2000);

    while (1)
    {
	   	CmdLCD(0x01);
	   	CmdLCD(0x80);
	   	StrLCD("1.ENROLL 3.DEL ");		
		CmdLCD(0xc0);
		StrLCD("2.SRH4.D.ALL5.E");
		choose = KeyScan();
		while(ColScan()==0);
	/*	switch(choose)
		{
		
		case '1':
			CmdLCD(0x01);
	   		CmdLCD(0x80);
	   		StrLCD("Enter ID: ");
			pageid = ReadNum();
	   		CmdLCD(0xC0);
	   		u32LCD(pageid);					
    		delay_ms(100);
			if(pageid>0 && pageid <10)
			{
				enroll(pageid);
			}
			break;
		case '2':
	   		CmdLCD(0x01);
	   		CmdLCD(0x80);
	   		StrLCD("PLACE FINGER");
         	CmdLCD(0xC0);
          	u32LCD(search_fp()); 
			delay_ms(1000); 
			break;
		case '3':
			CmdLCD(0x01);
	   		CmdLCD(0x80);
	   		StrLCD("Enter ID: ");
			pageid = ReadNum();
	   		CmdLCD(0xC0);
	   		u32LCD(pageid);					
    		delay_ms(100);
			if(pageid>0 && pageid <10)
			{
				if(delete_fp(pageid) == 0x00)
				{
					CmdLCD(0x01);
			   		CmdLCD(0x80);
			   		StrLCD("SELECTED ID DEL.");					
					delay_ms(1000);
				}
				else
				{
					CmdLCD(0x01);
			   		CmdLCD(0x80);
			   		StrLCD("Failed to del..");					
					delay_ms(1000);
				}
			}
			break;
		case '4':
			if(deleteall_fp() == 0x00)
			{
                CmdLCD(0x01);
                CmdLCD(0x80);
                StrLCD("DEL ALL SUCCUSS");					
				delay_ms(1000);	
			}
			else
			{
				CmdLCD(0x01);
			   	CmdLCD(0x80);
			   	StrLCD("Failed to del..");					
				delay_ms(1000);				
			}
			break;
		case '5': exit(0);
		} */
		if(KeyScan()=='1')
		{
				CmdLCD(0x01);
	   		CmdLCD(0x80);
	   		StrLCD("Enter ID: ");
			pageid = ReadNum();
	   		CmdLCD(0xC0);
	   		u32LCD(pageid);					
    		delay_ms(100);
			for(p=0;p<10;)
			{
				if(pageid>0 && pageid <10)
				{	   
					enroll(pageid);
					PageWrite_25LC512(0x000f+p,(u8*)pageid);
					p++;
				}
				else
				p=0;
			  }
		}
		else if( KeyScan()=='2')
		{
		CmdLCD(0x01);
	   		CmdLCD(0x80);
	   		StrLCD("PLACE FINGER");
         	CmdLCD(0xC0);
          	u32LCD(search_fp()); 
			delay_ms(1000); 
		}
		else if(KeyScan()=='3')
		{
			CmdLCD(0x01);
	   		CmdLCD(0x80);
	   		StrLCD("Enter ID: ");
			pageid = ReadNum();
	   		CmdLCD(0xC0);
	   		u32LCD(pageid);					
    		delay_ms(100);
			if(pageid>0 && pageid <10)
			{
				if(delete_fp(pageid) == 0x00)
				{
					CmdLCD(0x01);
			   		CmdLCD(0x80);
			   		StrLCD("SELECTED ID DEL.");					
					delay_ms(1000);
				}
				else
				{
					CmdLCD(0x01);
			   		CmdLCD(0x80);
			   		StrLCD("Failed to del..");					
					delay_ms(1000);
				}
			}
		}
		else if(KeyScan()=='4')
		{
			   	if(deleteall_fp() == 0x00)
			{
                CmdLCD(0x01);
                CmdLCD(0x80);
                StrLCD("DEL ALL SUCCUSS");					
				delay_ms(1000);	
			}
			else
			{
				CmdLCD(0x01);
			   	CmdLCD(0x80);
			   	StrLCD("Failed to del..");					
				delay_ms(1000);				
			}
		}
		else if(KeyScan()=='5')
		{
			break;
		}
    }
}
void edit_pass(void)
{
	PageWrite_25LC512(0x0000,"1111");
	CmdLCD(CLEAR_LCD);
	CmdLCD(GOTO_LINE1_POS0);
	StrLCD("Ent 4 dig cur Pass:");
	CmdLCD(GOTO_LINE2_POS0);
	pas=Readpass(pas);
	PageRead_25LC512(0x0000,4,curpass);
	if(!(strcmp((const char*)pas,(const char*)curpas)))
	{
		CmdLCD(CLEAR_LCD);
		CmdLCD(GOTO_LINE1_POS0);
		StrLCD("Ent 4 dig New pas:");
		CmdLCD(GOTO_LINE2_POS0);
		pas=Readpass(pas);
		CmdLCD(CLEAR_LCD);
		CmdLCD(GOTO_LINE1_POS0);
		StrLCD("Ent 4 dig New pas agn:");
		CmdLCD(GOTO_LINE2_POS0);
		newpas=Readpass(newpas);
		if(!(strcmp((const char*)pas,(const char*)newpas)))
		{
			PageWrite_25LC512(0x0000,newpas);
			CmdLCD(CLEAR_LCD);
			StrLCD("pwd chg sucful");
			delay_s(1);
			return;
		}
		else
		{
			CmdLCD(CLEAR_LCD);
			CmdLCD(GOTO_LINE1_POS0);
			StrLCD("Pwd chg fail");
			delay_ms(300);
			return;
		}
	}
	else
	{
		CmdLCD(CLEAR_LCD);
		CmdLCD(GOTO_LINE1_POS0);
		StrLCD("Pwd chg fail");
		delay_ms(200);
		return;
	}
}
