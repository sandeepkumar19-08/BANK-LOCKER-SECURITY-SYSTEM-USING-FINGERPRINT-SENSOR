//ext_int.h
#ifndef __EXT_INT_H__
#define __EXT_INT_H__
void eint1_isr(void) __irq;
void Enable_EINT1(void);
#endif
