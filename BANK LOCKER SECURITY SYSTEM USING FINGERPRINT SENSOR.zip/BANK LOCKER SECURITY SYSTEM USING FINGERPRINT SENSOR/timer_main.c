#include "timer.h"
int main()

{

    InitTimer0();

    //tdelay_us(1);

    //tdelay_ms(1);

    tdelay_s(5);

    while(1);	

}
